import React from 'react'
import Underconstruction from '../underconstruction/underconstruction'
function Records() {
  return (
    <div>
      <Underconstruction/>
    </div>
  )
}

export default Records
