import React from 'react'
import "leaflet/dist/leaflet.css";

function PharmacyStore() {
  return (
    <div>
      <div className="Geo-maps-conatiner">
        
      </div>
    </div>
  )
}

export default PharmacyStore
