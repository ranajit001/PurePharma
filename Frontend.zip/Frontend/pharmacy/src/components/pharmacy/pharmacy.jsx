import React from 'react'

function Pharmacy() {
  return (
    <>
      <div className="product-page-container">
        <h2 className='product-page-h2-tag'>Filter By</h2>
        <button className="product-filtration">SORT BY: {}</button>
      </div>
      <div className="product-page-product-list">
        <div className="filter-options-product-page">

        </div>
        <div className="product-list-product-page">
            
        </div>
      </div>
    </>
  )
}

export default Pharmacy
